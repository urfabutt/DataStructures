#ifndef BST_H
#define BST_H

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

class ItemType
{
private:
    string ID;
    string destination;
    string departure;
    string duration;
    string status;
   

public:
    
    ItemType();
    ItemType(string id, string dest, string dep, string dur, string status) {
        ID = id;
        destination = dest;
        departure = dep;
        duration = dur;
        status = status;
    }
    void Initialize(string, string, string, string, string);
    string getID() const;
    string getDestination() const;
    string getDeparture() const;
    string getDuration() const;
    string getStatus() const;
    void setStatus(string);
    void display() const;
    void displayETA() const;

    bool operator>(const ItemType&) const;
    bool operator<(const ItemType&) const;
    bool operator==(const ItemType&) const;
    bool operator!=(const ItemType&) const;
};

ItemType::ItemType() { ID = destination = departure = duration = status = ""; }
void ItemType::Initialize(string id, string des, string dep, string dur, string s)
{
    ID = id; destination = des; departure = dep; duration = dur; status = s;
}
string ItemType::getID() const { return ID; }
string ItemType::getDestination() const { return destination; }
string ItemType::getDeparture() const { return departure; }
string ItemType::getDuration() const { return duration; }
string ItemType::getStatus() const { return status; }
void ItemType::setStatus(string s) { status = s; }
bool ItemType::operator==(const ItemType& other) const { return ID == other.ID; }
bool ItemType::operator!=(const ItemType& other) const { return ID != other.ID; }
bool ItemType::operator<(const ItemType& other) const { return ID < other.ID; }
bool ItemType::operator>(const ItemType& other) const { return ID > other.ID; }
void ItemType::display() const
{
    cout << "Flight ID: " << ID << "\nDestination: " << destination
        << "\nDeparture: " << departure << "\nDuration: " << duration
        << " hrs\nStatus: " << status << "\n\n";
}
void ItemType::displayETA() const
{
    int dep = stoi(departure);
    int dur = stoi(duration);
    int eta = dep + dur;
    cout << left << setw(12) << ID << setw(15) << destination
        << setw(10) << departure << setw(8) << duration
        << setw(12) << status;
    if (eta >= 24) cout << setw(12) << ("1 day " + to_string(eta - 24) + "h");
    else cout << setw(12) << (to_string(eta) + "h");
    cout << endl;
}

struct Node
{
    ItemType key;
    Node* left;
    Node* right;
    Node* parent;
    Node(ItemType k) { key = k; left = right = parent = nullptr; }
};

class BST
{
private:
    Node* root = nullptr;
    void InOrder(Node*);
    Node* minimum(Node*);
    void Transplant(Node*, Node*);
    void displayETAHelper(Node*);
    void groupByDestination(Node*, string);
    void groupByStatus(Node*, string);
    void saveHelper(Node*, ofstream&);
    bool existsInFile(string, string);
public:
    void Insert(ItemType);
    Node* Search(ItemType);
    void Delete(ItemType);
    void display();
    void displayETAs();
    void displayByDestination(string);
    void displayByStatus(string);
    void loadFromFile(string);
    void saveToFile(string);

    Node* CancelHelper(Node* node, int threshold, bool& cancelledAny) {
        if (!node) return nullptr;
        node->left = CancelHelper(node->left, threshold, cancelledAny);
        node->right = CancelHelper(node->right, threshold, cancelledAny);
        if (node->key.getStatus() == "Delayed") {
            int flightDelay = stoi(node->key.getDuration()); 
            if (flightDelay > threshold) {
                cout << "Flight " << node->key.getID() << " cancelled.\n";
                cancelledAny = true;
                Node* temp = node;
                if (!node->left) {
                    Node* rightChild = node->right;
                    if (rightChild) rightChild->parent = node->parent;
                    delete temp;
                    return rightChild;
                }
                else if (!node->right) {
                    Node* leftChild = node->left;
                    if (leftChild) leftChild->parent = node->parent;
                    delete temp;
                    return leftChild;
                }
                else {
                    Node* minRight = minimum(node->right);
                    node->key = minRight->key; 
                    node->right = CancelHelper(node->right, threshold, cancelledAny); 
                }
            }
        }

        return node;
    }
    void CancelFlights() {
        int threshold;
        cout << "Enter delay threshold in hours to cancel flights: ";
        cin >> threshold;
        cin.ignore();

        bool cancelledAny = false;
        root = CancelHelper(root, threshold, cancelledAny);

        if (!cancelledAny)
            cout << "No flights were cancelled.\n";
    }

    void printSpaces(int count) 
    {
        for (int i = 0; i < count; i++) cout << " ";
    }
    void displayBSTHelper(Node* root, int space, int indent, int level) 
    {
        if (!root) return;
        space += indent;
        level++;
        displayBSTHelper(root->right, space, indent, level);
        cout << endl;
        printSpaces(space - indent);
        if (root->parent) 
        {
            cout << (root == root->parent->right ? "/ R:" : "\\ L:");
        }
        else 
        {
            cout << " R:";
        }
        cout << "**" << root->key.getID() << "**";
        if (root == this->root) {
            cout << " <-- **ROOT** (Level 1)\n";
        }
        else if (root == root->parent->right) 
        {
            cout << " (Level " << level << ") - **Right Child**\n";
        }
        else 
        {
            cout << " (Level " << level << ") - **Left Child**\n";
        }
        displayBSTHelper(root->left, space, indent, level);
    }

    void displayTree() 
    {
        if (!root) {
            cout << "BST is empty.\n";
            return;
        }
        cout << "\n** Flight Binary Search Tree ** \n";
        cout << "\n";
        displayBSTHelper(root, 0, 6, 0);
        cout << "\n";
    }

};


Node* BST::Search(ItemType k)
{
    Node* cur = root;
    while (cur && cur->key != k) cur = (k < cur->key) ? cur->left : cur->right;
    return cur;
}

void BST::Insert(ItemType k)
{
    if (Search(k)) { cout << "Flight with ID " << k.getID() << " already exists!\n"; return; }
    Node* z = new Node(k); Node* y = nullptr; Node* x = root;
    while (x) { y = x; x = (z->key < x->key) ? x->left : x->right; }
    z->parent = y;
    if (!y) root = z;
    else if (z->key < y->key) y->left = z; else y->right = z;
}

void BST::InOrder(Node* x)
{
    if (!x) return;
    InOrder(x->left); x->key.display(); InOrder(x->right);
}

void BST::display() { InOrder(root); }

Node* BST::minimum(Node* x) { while (x && x->left) x = x->left; return x; }

void BST::Transplant(Node* u, Node* v)
{
    if (!u->parent) root = v;
    else if (u == u->parent->left) u->parent->left = v;
    else u->parent->right = v;
    if (v) v->parent = u->parent;
}

void BST::Delete(ItemType k)
{
    Node* z = Search(k);
    if (!z) { cout << "Flight not found.\n"; return; }
    if (!z->left) Transplant(z, z->right);
    else if (!z->right) Transplant(z, z->left);
    else {
        Node* y = minimum(z->right);
        if (y->parent != z) { Transplant(y, y->right); y->right = z->right; y->right->parent = y; }
        Transplant(z, y); y->left = z->left; y->left->parent = y;
    }
    delete z;
}

void BST::displayETAHelper(Node* node)
{
    if (!node) return;
    displayETAHelper(node->left); node->key.displayETA(); displayETAHelper(node->right);
}

void BST::displayETAs()
{
    cout << left << setw(12) << "ID" << setw(15) << "Destination" << setw(10)
        << "Dep" << setw(8) << "Dur" << setw(12) << "Status" << setw(12) << "ETA" << endl;
    displayETAHelper(root);
}

void BST::groupByDestination(Node* x, string d)
{
    if (!x) return;
    groupByDestination(x->left, d);
    if (x->key.getDestination() == d) x->key.display();
    groupByDestination(x->right, d);
}

void BST::displayByDestination(string d)
{
    cout << "Flights going to: " << d << "\n\n"; groupByDestination(root, d);
}

void BST::groupByStatus(Node* x, string s)
{
    if (!x) return;
    groupByStatus(x->left, s);
    if (x->key.getStatus() == s) x->key.display();
    groupByStatus(x->right, s);
}

void BST::displayByStatus(string s)
{
    cout << "Flights with status: " << s << "\n\n"; groupByStatus(root, s);
}

void BST::loadFromFile(string filename)
{
    ifstream fin(filename);
    if (!fin) { cout << "Cannot open " << filename << ". Starting with empty database.\n"; return; }
    string id, dest, dep, dur, status;
    while (fin >> id >> dest >> dep >> dur >> status) { ItemType item; item.Initialize(id, dest, dep, dur, status); Insert(item); }
    fin.close();
}

bool BST::existsInFile(string filename, string id)
{
    ifstream fin(filename);
    if (!fin) return false;
    string fid; while (fin >> fid) { if (fid == id) return true; fin.ignore(1000, '\n'); }
    return false;
}

void BST::saveHelper(Node* node, ofstream& fout)
{
    if (!node) return; saveHelper(node->left, fout);
    fout << node->key.getID() << " " << node->key.getDestination() << " "
        << node->key.getDeparture() << " " << node->key.getDuration() << " "
        << node->key.getStatus() << endl;
    saveHelper(node->right, fout);
}

void BST::saveToFile(string filename)
{
    ofstream fout(filename);
    if (!fout) { cout << "Cannot write to " << filename << endl; return; }
    saveHelper(root, fout); fout.close();
}

#endif
