#ifndef AVL_H
#define AVL_H

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include "BST.h" 
using namespace std;

struct AVLNode
{
    ItemType key;
    AVLNode* left;
    AVLNode* right;
    int height;
    AVLNode(ItemType k) { key = k; left = right = nullptr; height = 1; }
};

class AVL
{
private:
    void printSpaces(int count) const 
    {
        for (int i = 0; i < count; i++) cout << " ";
    }
    AVLNode* root = nullptr;
    int rotationCount = 0;

    int height(AVLNode* N) { return N ? N->height : 0; }
    int balanceFactor(AVLNode* N) { return N ? height(N->left) - height(N->right) : 0; }
    
    AVLNode* rightRotate(AVLNode* y)
    {
        rotationCount++;
        AVLNode* x = y->left;
        AVLNode* T2 = x->right;
        x->right = y;
        y->left = T2;
        y->height = max(height(y->left), height(y->right)) + 1;
        x->height = max(height(x->left), height(x->right)) + 1;
        return x;
    }

    AVLNode* leftRotate(AVLNode* x)
    {
        rotationCount++;
        AVLNode* y = x->right;
        AVLNode* T2 = y->left;
        y->left = x;
        x->right = T2;
        x->height = max(height(x->left), height(x->right)) + 1;
        y->height = max(height(y->left), height(y->right)) + 1;
        return y;
    }

    AVLNode* insertNode(AVLNode* node, ItemType key)
    {
        if (!node)
            return new AVLNode(key);
        if (key < node->key) 
            node->left = insertNode(node->left, key);
        else if (key > node->key) 
            node->right = insertNode(node->right, key);
        else 
        { 
            cout << "Flight ID " << key.getID() << " already exists in AVL!\n"; 
            return node; 
        }

        node->height = 1 + max(height(node->left), height(node->right));
        int bf = balanceFactor(node);
        // LL
        if (bf > 1 && key < node->left->key) return rightRotate(node);
        // RR
        if (bf < -1 && key > node->right->key) return leftRotate(node);
        // LR
        if (bf > 1 && key > node->left->key) { node->left = leftRotate(node->left); return rightRotate(node); }
        // RL
        if (bf < -1 && key < node->right->key) { node->right = rightRotate(node->right); return leftRotate(node); }

        return node;
    }

    void inOrder(AVLNode* node)
    {
        if (!node) return;
        inOrder(node->left);
        node->key.display();
        inOrder(node->right);
    }

    void printETAHelper(AVLNode* node)
    {
        if (!node) return;
        printETAHelper(node->left);
        node->key.displayETA();
        printETAHelper(node->right);
    }

    AVLNode* minValueNode(AVLNode* node)
    {
        AVLNode* current = node;
        while (current && current->left) current = current->left;
        return current;
    }

    AVLNode* deleteNode(AVLNode* root, ItemType key)
    {
        if (!root) { cout << "Flight not found in AVL.\n"; return root; }

        if (key < root->key) root->left = deleteNode(root->left, key);
        else if (key > root->key) root->right = deleteNode(root->right, key);
        else
        {
            if (!root->left || !root->right)
            {
                AVLNode* temp = root->left ? root->left : root->right;
                if (!temp) { temp = root; root = nullptr; }
                else *root = *temp;
                delete temp;
            }
            else
            {
                AVLNode* temp = minValueNode(root->right);
                root->key = temp->key;
                root->right = deleteNode(root->right, temp->key);
            }
        }

        if (!root) return root;

        root->height = 1 + max(height(root->left), height(root->right));
        int bf = balanceFactor(root);

        // LL
        if (bf > 1 && balanceFactor(root->left) >= 0) return rightRotate(root);
        // LR
        if (bf > 1 && balanceFactor(root->left) < 0) { root->left = leftRotate(root->left); return rightRotate(root); }
        // RR
        if (bf < -1 && balanceFactor(root->right) <= 0) return leftRotate(root);
        // RL
        if (bf < -1 && balanceFactor(root->right) > 0) { root->right = rightRotate(root->right); return leftRotate(root); }

        return root;
    }

    void saveHelper(AVLNode* node, ofstream& fout)
    {
        if (!node) return;
        saveHelper(node->left, fout);
        fout << node->key.getID() << " " << node->key.getDestination() << " "
            << node->key.getDeparture() << " " << node->key.getDuration() << " "
            << node->key.getStatus() << endl;
        saveHelper(node->right, fout);
    }
     AVLNode* searchNode(AVLNode* node, ItemType key) 
     {
            if (!node) return nullptr;
            if (key < node->key) return searchNode(node->left, key);
            else if (key > node->key) return searchNode(node->right, key);
            else return node; 
     }

public:
  
    void printAVLHorizontal(AVLNode* node, int space, int indent, int level, int role) 
    {
        if (node == nullptr)
            return;
        space += indent;
        level++;
        printAVLHorizontal(node->right, space, indent, level, 1);
        cout << endl;
        printSpaces(space - indent);
        string label = "";
        string connection = "";

        if (role == 0) 
        {
            label = " <-- **ROOT** (Level 1) [H:" + to_string(node->height) + "]";
            connection = " R:"; 
        }
        else if (role == 1) 
        {
            label = " (Level " + to_string(level) + ") - **Right Child** [H:" + to_string(node->height) + "]";
            connection = "/ R:";
        }
        else
        {
            label = " (Level " + to_string(level) + ") - **Left Child** [H:" + to_string(node->height) + "]";
            connection = "\\ L:";
        }
        cout << connection << " **" << node->key.getID() << "**" << label << "\n";
        printAVLHorizontal(node->left, space, indent, level, -1);
    }

    void displayAVLTree() 
    {
        if (!root) 
        {
            cout << "\n AVL Tree is empty.\n";
            return;
        }
        cout << "\n **Flight AVL Tree ** \n";
        cout << "\n";
        printAVLHorizontal(root, 0, 6, 0, 0);
        cout << "\n";
    }
    AVLNode* Search(ItemType key) 
    {
        return searchNode(root, key);
    }
    void insert(ItemType key) 
    { 
        root = insertNode(root, key); 
    }
    void del(ItemType key) 
    { 
        root = deleteNode(root, key); 
    }
    void inOrderDisplay() 
    { 
        inOrder(root); 
    }
    void printETAs()
    {
        cout << left << setw(12) << "ID" << setw(15) << "Destination" << setw(10)
            << "Dep" << setw(8) << "Dur" << setw(12) << "Status" << setw(12) << "ETA" << endl;
        printETAHelper(root);
    }
    int getRotationCount() { return rotationCount; }

    void loadFromFile(string filename)
    {
        ifstream fin(filename);
        if (!fin) return;
        string id, dest, dep, dur, status;
        while (fin >> id >> dest >> dep >> dur >> status)
        {
            ItemType item;
            item.Initialize(id, dest, dep, dur, status);
            insert(item);
        }
        fin.close();
    }

    void saveToFile(string filename)
    {
        ofstream fout(filename);
        if (!fout) { cout << "Cannot write to " << filename << endl; return; }
        saveHelper(root, fout);
        fout.close();
    }
};

#endif
