#include <iostream>
#include <string>
#include <chrono>
#include "BST.h"
#include "AVL.h"
#include "BFS.h"
#include <fstream>
using namespace std;
using namespace chrono;

int main() {
    BST bst;
    AVL avl;
    AirportGraph graph;
    bst.loadFromFile("flights.txt");
    avl.loadFromFile("flights.txt");
    ifstream finAirports("airports.txt");
    if (finAirports) {
        string id, name, city, country, emergency;
        while (finAirports >> id >> name >> city >> country >> emergency) {
            graph.addAirport(id, name, city, country, emergency);
        }
        finAirports.close();
    }

    ifstream finRoutes("routes.txt");
    if (finRoutes) {
        string from, to;
        while (finRoutes >> from >> to) {
            graph.addRoute(from, to);
        }
        finRoutes.close();
    }

    int choice;
    do {
        cout << "\n------------------------------\n";
        cout << "1.  Add Flight (BST & AVL)\n";
        cout << "2.  Delete Flight (BST & AVL)\n";
        cout << "3.  Search Flight (BST)\n";
        cout << "4.  Display All Flights (BST)\n";
        cout << "5.  Display Flights by Destination (BST)\n";
        cout << "6.  Display Flights by Status (BST)\n";
        cout << "7.  Cancel Delayed Flights (BST)\n";
        cout << "8.  Display Flight ETAs (AVL)\n";
        cout << "9.  Load Flights from File\n";
        cout << "10. Save Flights to File\n";
        cout << "11. Add Airport\n";
        cout << "12. Add Route\n";
        cout << "13. Airport BFS - Route & Distance\n";
        cout << "14. AVL Inorder Traversal & Rotation Count\n";
        cout << "15. Search Time Comparison (BST vs AVL)\n";
        cout << "16. BST of Flights\n";
        cout << "17. AVL of Flights\n";
        cout << "0.  Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();

        switch (choice) 
        {
        case 1: 
        { 
            string id, dest, dep, dur, status;
            cout << "Enter Flight ID: "; getline(cin, id);
            cout << "Enter Destination: "; getline(cin, dest);
            cout << "Enter Departure hour (0-23): "; getline(cin, dep);
            cout << "Enter Duration (hrs): "; getline(cin, dur);
            cout << "Enter Status (OnTime/Delayed/Cancelled): "; getline(cin, status);
            ItemType item;
            item.Initialize(id, dest, dep, dur, status);
            bst.Insert(item);
            avl.insert(item);
            break;
        }
        case 2: 
        {
            string id;
            cout << "Enter Flight ID to delete: "; getline(cin, id);
            ItemType item; item.Initialize(id, "", "", "", "");
            bst.Delete(item);
            avl.del(item);
            break;
        }
        case 3:
        {
            string id;
            cout << "Enter Flight ID to search: "; getline(cin, id);
            ItemType item; item.Initialize(id, "", "", "", "");
            Node* found = bst.Search(item);
            if (found) found->key.display();
            else cout << "Flight not found.\n";
            break;
        }
        case 4:
            bst.display();
            break;
        case 5: 
        {
            string dest;
            cout << "Enter Destination: "; getline(cin, dest);
            bst.displayByDestination(dest);
            break;
        }
        case 6: 
        {
            string status;
            cout << "Enter Status: "; getline(cin, status);
            bst.displayByStatus(status);
            break;
        }
        case 7:
            bst.CancelFlights();
            break;
        case 8:
            avl.printETAs();
            break;
        case 9:
            bst.loadFromFile("flights.txt");
            avl.loadFromFile("flights.txt");
            cout << "Flights loaded.\n";
            break;
        case 10:
            bst.saveToFile("flights.txt");
            avl.saveToFile("flights.txt");
            cout << "Flights saved.\n";
            break;
        case 11: { 
            string id, name, city, country, emergency;
            cout << "Enter Airport ID: "; getline(cin, id);
            cout << "Enter Name: "; getline(cin, name);
            cout << "Enter City: "; getline(cin, city);
            cout << "Enter Country: "; getline(cin, country);
            cout << "Emergency availability (Yes/No): "; getline(cin, emergency);
            graph.addAirport(id, name, city, country, emergency);
            graph.saveAirportsToFile("airports.txt");
            break;
        }
        case 12: { 
            string from, to;
            cout << "Enter source airport ID: "; getline(cin, from);
            cout << "Enter destination airport ID: "; getline(cin, to);
            graph.addRoute(from, to);
            graph.saveRoutesToFile("routes.txt");
            break;
        }
        case 13: { 
            int subchoice;
            cout << "1. BFS table from source airport\n";
            cout << "2. Route from source to destination\n";
            cout << "Enter choice: "; cin >> subchoice; cin.ignore();
            if (subchoice == 1) {
                string src; cout << "Enter source airport ID: "; getline(cin, src);
                graph.printBFSTable(src);
            }
            else if (subchoice == 2) {
                string src, dest;
                cout << "Enter source airport ID: "; getline(cin, src);
                cout << "Enter destination airport ID: "; getline(cin, dest);
                graph.printRoute(src, dest);
            }
            else
                cout << "Invalid choice.\n";
            break;
        }
        case 14: 
        { 
            cout << "\nAVL Inorder Traversal:\n";
            avl.inOrderDisplay();
            cout << "\nTotal Rotations: " << avl.getRotationCount() << endl;
            break;
        }
        case 15: 
        { 
            string id;
            cout << "Enter Flight ID to search: "; getline(cin, id);
            ItemType item; item.Initialize(id, "", "", "", "");

            auto startBST = high_resolution_clock::now();
            Node* foundBST = bst.Search(item);
            auto endBST = high_resolution_clock::now();
            auto durBST = duration_cast<nanoseconds>(endBST - startBST).count();

            auto startAVL = high_resolution_clock::now();
            bool foundAVL = avl.Search(item);
            auto endAVL = high_resolution_clock::now();
            auto durAVL = duration_cast<nanoseconds>(endAVL - startAVL).count();

            cout << "BST search: " << (foundBST ? "Found" : "Not Found") << " in " << durBST << " ns\n";
            cout << "AVL search: " << (foundAVL ? "Found" : "Not Found") << " in " << durAVL << " ns\n";
            break;
        }
        case 16:
            bst.displayTree();
            break;
        case 17:
            avl.displayAVLTree();
            break;
        case 0:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}

