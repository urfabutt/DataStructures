#ifndef BFS_H
#define BFS_H

#include <iostream>
#include <string>
#include <fstream>
#include<queue>
using namespace std;

class AdjNode 
{
public:
    string dest;
    AdjNode* next;

    AdjNode(string d) 
    {
        dest = d;
        next = nullptr;
    }
};

class AirportGraph 
{
private:
    string airports[50];      
    string names[50];      
    string cities[50];
    string countries[50];
    string emergencies[50];
    AdjNode* list[50];       
    int airportCount;       
    int findIndex(string a) 
    {
        for (int i = 0; i < airportCount; i++)
            if (airports[i] == a)
                return i;
        return -1;
    }

public:
    AirportGraph() 
    {
        airportCount = 0;
        for (int i = 0; i < 50; i++)
            list[i] = nullptr;
    }
    void addAirport(string id, string name, string city, string country, string emergency) 
    {
        if (findIndex(id) != -1) return;  
        airports[airportCount] = id;
        names[airportCount] = name;
        cities[airportCount] = city;
        countries[airportCount] = country;
        emergencies[airportCount] = emergency;
        list[airportCount] = nullptr;
        airportCount++;
    }

    void addRoute(string from, string to) 
    {
        int i = findIndex(from);
        int j = findIndex(to);
        if (i == -1 || j == -1) {
            cout << "One of the airports does not exist.\n";
            return;
        }
        AdjNode* n1 = new AdjNode(to);
        n1->next = list[i];
        list[i] = n1;
        AdjNode* n2 = new AdjNode(from);
        n2->next = list[j];
        list[j] = n2;
    }
    void BFS(string src, int distance[], int parent[]) 
    {
        int s = findIndex(src);
        if (s == -1) { cout << "Source airport not found.\n"; return; }

        bool visited[50] = { false };
        for (int i = 0; i < 50; i++) parent[i] = -1;

        queue<int> q;
        q.push(s);
        visited[s] = true;
        distance[s] = 0;

        while (!q.empty()) {
            int curr = q.front(); q.pop();
            AdjNode* temp = list[curr];
            while (temp) {
                int idx = findIndex(temp->dest);
                if (!visited[idx]) {
                    visited[idx] = true;
                    parent[idx] = curr;
                    distance[idx] = distance[curr] + 1;
                    q.push(idx);
                }
                temp = temp->next;
            }
        }
    }

    void printRoute(string src, string dest) 
    {
        int distance[50], parent[50];
        BFS(src, distance, parent);
        int s = findIndex(src), d = findIndex(dest);
        if (s == -1 || d == -1) { cout << "One of the airports does not exist.\n"; return; }
        if (parent[d] == -1 && s != d) { cout << "No route exists.\n"; return; }

        int path[50], count = 0, curr = d;
        while (curr != -1) { path[count++] = curr; curr = parent[curr]; }

        cout << "Route: ";
        for (int i = count - 1; i >= 0; i--) {
            cout << names[path[i]];
            if (i > 0) cout << " -> ";
        }
        cout << "\nDistance (hops): " << count - 1 << "\n";
    }

    void printBFSTable(string src) 
    {
        int distance[50], parent[50];
        BFS(src, distance, parent);
        cout << "Airport\tDistance\tParent\n";
        for (int i = 0; i < airportCount; i++) {
            string parentName = (parent[i] == -1 ? "None" : names[parent[i]]);
            cout << names[i] << "\t" << distance[i] << "\t\t" << parentName << "\n";
        }
    }

    void saveAirportsToFile(const string& filename) 
    {
        ofstream fout(filename);
        if (!fout) 
        { 
            cout << "Cannot write to " << filename << endl;
            return;
        }
        for (int i = 0; i < airportCount; i++) 
        {
            fout << airports[i] << " " << names[i] << " " << cities[i] << " "
                << countries[i] << " " << emergencies[i] << endl;
        }
        fout.close();
    }

    void saveRoutesToFile(const string& filename) 
    {
        ofstream fout(filename);
        if (!fout) 
        { 
            cout << "Cannot write to " << filename << endl; 
            return; 
        }
        for (int i = 0; i < airportCount; i++) 
        {
            AdjNode* temp = list[i];
            while (temp) 
            {
                fout << airports[i] << " " << temp->dest << endl;
                temp = temp->next;
            }
        }
        fout.close();
    }
    int getAirportCount() 
    { 
        return airportCount; 
    }
    string getAirportName(int idx) 
    { 
        return names[idx]; 
    }
    string getAirportID(int idx) 
    { 
        return airports[idx]; 
    }
};

#endif








